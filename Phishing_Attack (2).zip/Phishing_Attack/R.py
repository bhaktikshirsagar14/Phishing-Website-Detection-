import tkinter as tk
from tkinter import filedialog
import csv
import os
from urllib.request import urlretrieve

def detect_rosmware(csv_file, file_number):
    # Define expected headers for different file numbers
    expected_headers = {
        1: ["ROSMware", "header1", "fields"],
        2: ["ROSMware", "header2", "fields"],
        3: ["ROSMware", "header3", "fields"],
        4: ["ROSMware", "header4", "fields"],
        5: ["ROSMware", "header5", "fields"],
        # For files beyond the first five, use a general header
        'other': ["ROSMware", "header", "fields"]
    }
    expected_header = expected_headers.get(file_number, expected_headers['other'])
    
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        header = next(reader)  # Read the header of the CSV file
        if header == expected_header:
            return "ROSMware format detected."
        else:
            return "Normal CSV file."

def download_file(file_path):
    file_name = os.path.basename(file_path)
    save_path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=file_name)
    if save_path:
        urlretrieve(f"file://{file_path}", save_path)
        return f"File '{file_name}' downloaded successfully."
    else:
        return "Download canceled."

def select_files():
    file_paths = filedialog.askopenfilenames(filetypes=[("CSV files", "*.csv")])
    if file_paths:
        for index, file_path in enumerate(file_paths, start=1):
            result = detect_rosmware(file_path, index)
            file_name = os.path.basename(file_path)
            download_button = tk.Button(result_text, text="Download", command=lambda f=file_path: download_file(f))
            result_text.insert(tk.END, f"{file_name}: {result}\n")
            result_text.window_create(tk.END, window=download_button)
            result_text.insert(tk.END, "\n")

root = tk.Tk()
root.title("CSV File Detector")

select_button = tk.Button(root, text="Select CSV Files", command=select_files)
select_button.pack(pady=20)

result_text = tk.Text(root)
result_text.pack(pady=10, padx=10, fill=tk.BOTH, expand=True)

root.mainloop()
