import tkinter as tk
from tkinter import filedialog, messagebox
import csv
import urllib.request
from PIL import Image, ImageTk

def detect_rosmware(csv_data):
    for row in csv_data:
        if all(value == '1' for value in row):
            return "ROSMware format detected."
        elif all(value == '0' for value in row):
            return "Normal CSV file."
        else:
            return "Mixed values found, cannot determine format."

def download_csv(file_path):
    # Here you can specify the directory where you want to save the downloaded CSV file
    save_path = filedialog.asksaveasfilename(defaultextension=".csv")
    if save_path:
        # Copy the file to the specified directory
        with open(file_path, 'rb') as f:
            with open(save_path, 'wb') as new_file:
                new_file.write(f.read())
        result_label.config(text="CSV file downloaded.")

def download_rosmware():
    # Display a warning message about ROSMware
    messagebox.showwarning("ROSMware Detected", "ROSMware format detected. It may harm your PC. Do not download or execute it.")

def select_file_and_detect():
    file_path = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    if file_path:
        with open(file_path, 'r') as file:
            reader = csv.reader(file)
            csv_data = list(reader)
        result = detect_rosmware(csv_data)
        result_label.config(text=result)
        if "ROSMware" in result:
            download_rosmware()
        else:
            download_button.config(state="normal", command=lambda: download_csv(file_path))

# Create the tkinter window
root = tk.Tk()
root.title("CSV File Format Detector")

# Add a background image
image = Image.open("1.jpg")  # Replace "1.jpg" with your image file
background_image = ImageTk.PhotoImage(image)

# Create a label to display the background image
background_label = tk.Label(root, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)

# Create labels
title_label = tk.Label(root, text="Rosmware file detection", font=("Helvetica", 24), bg="white")
title_label.place(x=100, y=50)

result_label = tk.Label(root, text="", font=("Helvetica", 14), bg="white")
result_label.place(x=700, y=300)

# Create a button to select a file
select_button = tk.Button(root, text="Select CSV File", command=select_file_and_detect)
select_button.place(x=100, y=150)

# Create a download button (initially disabled)
download_button = tk.Button(root, text="Download CSV File", state="disabled")
download_button.place(x=100, y=200)

# Run the tkinter event loop
root.mainloop()
