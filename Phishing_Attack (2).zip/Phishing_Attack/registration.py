import tkinter as tk
from tkinter import messagebox as ms
import sqlite3
from PIL import Image, ImageTk
import re



window = tk.Tk()
window.geometry("1600x800")
window.title("REGISTRATION FORM")
window.configure(background="grey")

Fullname = tk.StringVar()
address = tk.StringVar()
username = tk.StringVar()
Email = tk.StringVar()
Phoneno = tk.IntVar()
var = tk.IntVar()
age = tk.IntVar()
password = tk.StringVar()
password1 = tk.StringVar()

# value = random.randint(1, 1000)
# print(value)

# database code
db = sqlite3.connect('evaluation.db')
cursor = db.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS registration"
               "(Fullname TEXT, address TEXT, username TEXT, Email TEXT, Phoneno TEXT,Gender TEXT,age TEXT , password TEXT)")
db.commit()



def password_check(passwd): 
	
	SpecialSym =['$', '@', '#', '%'] 
	val = True
	
	if len(passwd) < 6: 
		print('length should be at least 6') 
		val = False
		
	if len(passwd) > 20: 
		print('length should be not be greater than 20') 
		val = False
		
	if not any(char.isdigit() for char in passwd): 
		print('Password should have at least one numeral') 
		val = False
		
	if not any(char.isupper() for char in passwd): 
		print('Password should have at least one uppercase letter') 
		val = False
		
	if not any(char.islower() for char in passwd): 
		print('Password should have at least one lowercase letter') 
		val = False
		
	if not any(char in SpecialSym for char in passwd): 
		print('Password should have at least one of the symbols $@#') 
		val = False
	if val:  
		return val 

def insert():
    fname = Fullname.get()
    addr = address.get()
    un = username.get()
    email = Email.get()
    mobile = Phoneno.get()
    gender = var.get()
    time = age.get()
    pwd = password.get()
    cnpwd = password1.get()

    with sqlite3.connect('evaluation.db') as db:
        c = db.cursor()

    # Find Existing username if any take proper action
    find_user = ('SELECT * FROM registration WHERE username = ?')
    c.execute(find_user, [(username.get())])

    # else:
    #   ms.showinfo('Success!', 'Account Created Successfully !')

    # to check mail
    #regex = '^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$'
    regex='^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'
    if (re.search(regex, email)):
        a = True
    else:
        a = False
    # validation
    if (fname.isdigit() or (fname == "")):
        ms.showinfo("Message", "please enter valid name")
    elif (addr == ""):
        ms.showinfo("Message", "Please Enter Address")
    elif (email == "") or (a == False):
        ms.showinfo("Message", "Please Enter valid email")
    elif((len(str(mobile)))<10 or len(str((mobile)))>10):
        ms.showinfo("Message", "Please Enter 10 digit mobile number")
    elif ((time > 100) or (time == 0)):
        ms.showinfo("Message", "Please Enter valid age")
    elif (c.fetchall()):
        ms.showerror('Error!', 'Username Taken Try a Diffrent One.')
    elif (pwd == ""):
        ms.showinfo("Message", "Please Enter valid password")
    elif (var == False):
        ms.showinfo("Message", "Please Enter gender")
    elif(pwd=="")or(password_check(pwd))!=True:
        ms.showinfo("Message", "password must contain atleast 1 Uppercase letter,1 symbol,1 number")
    elif (pwd != cnpwd):
        ms.showinfo("Message", "Password Confirm password must be same")
    else:
        conn = sqlite3.connect('evaluation.db')
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                'INSERT INTO registration(Fullname, address, username, Email, Phoneno, Gender, age , password) VALUES(?,?,?,?,?,?,?,?)',
                (fname, addr, un, email, mobile, gender, time, pwd))

            conn.commit()
            db.close()
            ms.showinfo('Success!', 'Account Created Successfully !')
            # window.destroy()
            window.destroy()
            
            from subprocess import call
            call(["python", "login.py"])

########################################################################################################################




# assign and define variable
# def login():

#####For background Image
image2 = Image.open('re.jpg')
image2 = image2.resize((1800, 900), Image.ANTIALIAS)

background_image = ImageTk.PhotoImage(image2)

background_label = tk.Label(window, image=background_image)

background_label.image = background_image

background_label.place(x=0, y=0, relwidth=1, relheight=1)

l1 = tk.Label(window, text="Registration Form", font=("Times new roman", 30, "bold"), bg="#8B0A50", fg="white")
l1.place(x=610, y=50)

# that is for label1 registration

l2 = tk.Label(window, text="Full Name :", width=14, font=("Times new roman", 15), bg="#B452CD", fg="white")
l2.place(x=465, y=150)
t1 = tk.Entry(window, textvar=Fullname, width=35, font=('', 15))
t1.place(x=700, y=150)
# that is for label 2 (full name)


l3 = tk.Label(window, text="Address :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l3.place(x=465, y=200)
t2 = tk.Entry(window, textvar=address, width=35, font=('', 15))
t2.place(x=700, y=200)
# that is for label 3(address)


# that is for label 4(blood group)

l5 = tk.Label(window, text="E-mail :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l5.place(x=465, y=250)
t4 = tk.Entry(window, textvar=Email, width=35, font=('', 15))
t4.place(x=700, y=250)
# that is for email address

l6 = tk.Label(window, text="Phone number :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l6.place(x=465, y=300)
t5 = tk.Entry(window, textvar=Phoneno, width=35, font=('', 15))
t5.place(x=700, y=300)
# phone number
l7 = tk.Label(window, text="Gender :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l7.place(x=465, y=350)
# gender
tk.Radiobutton(window, text="Male", padx=5, width=10, bg="#FF69B4", font=("bold", 15), variable=var, value=1).place(x=700,
                                                                                                                y=350)
tk.Radiobutton(window, text="Female", padx=20, width=12, bg="#FF69B4", font=("bold", 15), variable=var, value=2).place(
    x=880, y=350)

l8 = tk.Label(window, text="Age :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l8.place(x=465, y=400)
t6 = tk.Entry(window, textvar=age, width=35, font=('', 15))
t6.place(x=700, y=400)

l4 = tk.Label(window, text="User Name :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l4.place(x=465, y=450)
t3 = tk.Entry(window, textvar=username, width=35, font=('', 15))
t3.place(x=700, y=450)

l9 = tk.Label(window, text="Password :", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l9.place(x=465, y=500)
t9 = tk.Entry(window, textvar=password, width=35, font=('', 15), show="*")
t9.place(x=700, y=500)

l10 = tk.Label(window, text="Confirm Password:", width=14, font=("Times new roman", 15, "bold"), bg="#B452CD", fg="white")
l10.place(x=465, y=550)

t10 = tk.Entry(window, textvar=password1, width=35, font=('', 15), show="*")
t10.place(x=700, y=550)

btn = tk.Button(window, text="Register", bg="#8B0A50",font=("",20),fg="white", width=9, height=1, command=insert)
btn.place(x=700, y=620)
# tologin=tk.Button(window , text="Go To Login", bg ="dark green", fg = "white", width=15, height=2, command=login)
# tologin.place(x=330, y=600)
window.mainloop()