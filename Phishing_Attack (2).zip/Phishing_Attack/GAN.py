import numpy as np
import pandas as pd
from tensorflow.keras import layers, models

# Load and preprocess the CSV dataset
# Replace 'your_dataset.csv' with the path to your CSV file
df = pd.read_csv('E:/project 2023/Phishing_Attack/Phishing_Attack/combined_dataset.csv')
data = df.values

# Normalize the data to a range of [0, 1]
data = (data - data.min()) / (data.max() - data.min())

# Generator model
def build_generator(latent_dim, output_dim):
    model = models.Sequential()
    model.add(layers.Dense(128, input_dim=latent_dim, activation='relu'))
    model.add(layers.Dense(output_dim, activation='sigmoid'))
    return model

# Discriminator model
def build_discriminator(input_dim):
    model = models.Sequential()
    model.add(layers.Dense(128, input_dim=input_dim, activation='relu'))
    model.add(layers.Dense(1, activation='sigmoid'))
    return model

# Combine generator and discriminator into a GAN model
def build_gan(generator, discriminator):
    discriminator.trainable = False
    model = models.Sequential()
    model.add(generator)
    model.add(discriminator)
    return model

# Build and compile the models
latent_dim = 100  # Adjust based on your requirements
output_dim = data.shape[1]  # Output dimension of the generator should match the number of features in your dataset

generator = build_generator(latent_dim, output_dim)
discriminator = build_discriminator(output_dim)
gan = build_gan(generator, discriminator)

discriminator.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
gan.compile(optimizer='adam', loss='binary_crossentropy')

# Training the GAN
def train_gan(epochs, batch_size):
    for epoch in range(epochs):
        for _ in range(data.shape[0] // batch_size):
            noise = np.random.normal(0, 1, (batch_size, latent_dim))
            generated_data = generator.predict(noise)

            real_data = data[np.random.randint(0, data.shape[0], batch_size)]
            labels_real = np.ones((batch_size, 1))
            labels_fake = np.zeros((batch_size, 1))

            d_loss_real = discriminator.train_on_batch(real_data, labels_real)
            d_loss_fake = discriminator.train_on_batch(generated_data, labels_fake)

            d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

            noise = np.random.normal(0, 1, (batch_size, latent_dim))
            labels_gan = np.ones((batch_size, 1))

            g_loss = gan.train_on_batch(noise, labels_gan)

        print(f"Epoch {epoch + 1}/{epochs}, [D loss: {d_loss[0]}, acc.: {100 * d_loss[1]}], [G loss: {g_loss}]")

# Train the GAN for 10 epochs with a batch size of 128
train_gan(epochs=10, batch_size=128)

# Generate synthetic data using the trained generator
num_samples = 1000  # Adjust based on your requirements
generated_data = generator.predict(np.random.normal(0, 1, (num_samples, latent_dim)))

# Save the generated data to a CSV file
generated_df = pd.DataFrame(generated_data, columns=df.columns)  # Assuming your dataset has column names
generated_df.to_csv('generated_data.csv', index=False)
